from colorama import init, Fore
import webbrowser


print(Fore.GREEN + '''
   ____ _             _      ____                           _             
  / ___| | ___  _   _| |_   / ___| ___ _ __   ___ _ __ __ _| |_ ___  _ __ 
 | |   | |/ _ \| | | | __| | |  _ / _ \ '_ \ / _ \ '__/ _` | __/ _ \| '__|
 | |___| | (_) | |_| | |_| | |_| |  __/ | | |  __/ | | (_| | || (_) | |   
  \____|_|\___/ \__,_|\__|  \____|\___|_| |_|\___|_|  \__,_|\__\___/|_|   
                                                                       
''')
print("This generator will not always have correct and valid codes, you need to download a Nitro Checker\n")
print("If you record a youtube video on this generator, we will not take it down!\n")
input("Press ENTER key to Start!\n")


num = input('How many nitro codes do you want to generate?: ')
charSet = f"{string.ascii_uppercase}{string.digits}{string.ascii_lowercase}"
bigStr = ""

with open("Generated Codes.txt","w", encoding='utf-8') as file:

    print(f'{Fore.BLUE} Wait!] Do not close, it takes a while to generate!')

    for i in range(int(num)):
        bigStr += f'https://discord.gift/{"".join(random.choices(charSet, k = 16))}\n'
        if i % 100_000 == 0:
            file.write(f'{bigStr}\n')
            bigStr = ""


    print(f'{Fore.CYAN} Successful] The codes should be in Generated Codes.txt"')
    input("Press Enter To Close!")
